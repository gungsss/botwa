function _0x481f(_0x2d9a8c, _0x5cf6ea) {
  const _0x5b4026 = _0x5b40();
  return (
    (_0x481f = function (_0x481fd1, _0x38e3d2) {
      _0x481fd1 = _0x481fd1 - 0x1a5;
      let _0x18b451 = _0x5b4026[_0x481fd1];
      return _0x18b451;
    }),
    _0x481f(_0x2d9a8c, _0x5cf6ea)
  );
}
function _0x5b40() {
  const _0x1ccc65 = [
    "-filter_complex",
    "blue",
    "resolve",
    "freeze",
    "catch",
    "649pMZqFi",
    "node-fetch",
    "test",
    "close",
    "API",
    "sessions",
    "loadDatabase",
    "info",
    "stdin",
    "requestPairingCode",
    "demote",
    "prefix",
    "warn",
    "authState",
    "Your\x20Pairing\x20Code\x20:\x20",
    "handler",
    "statusCode",
    "color",
    "fromEntries",
    "write",
    "./config",
    "-loglevel",
    "syntax\x20error\x20while\x20loading\x20\x27",
    "-type",
    "@user\x20sekarang\x20admin!",
    "localeCompare",
    "6nYWQcq",
    "all",
    "readyState",
    "chain",
    "deleted\x20plugin\x20\x27",
    "welcome",
    "12GrZzCc",
    "existsSync",
    "ffprobe",
    "reload",
    "filter",
    "--code",
    "4cZEekY",
    "loggedOut",
    "bgWhite",
    "version",
    "forEach",
    "Ubuntu",
    "readdirSync",
    ",\x20isLatest:\x20",
    "entries",
    "bye",
    "question",
    "slice",
    "-amin",
    "--mobile",
    "read",
    "294362uFQyXl",
    "-hide_banner",
    "creds",
    "log",
    "bind",
    "--\x20using\x20WA\x20v",
    "watch",
    "done",
    "child_process",
    "stdout",
    "parse",
    "includes",
    "--version",
    "chalk",
    "tmp",
    "readline",
    "match",
    "23543741rBCtpZ",
    "readFileSync",
    "./lib/lowdb",
    "some",
    "cache",
    "bgGreen",
    "conn",
    "201960bAkgyp",
    "timestamp",
    "listMessage",
    "32oPHpYQ",
    "Stickers\x20may\x20not\x20work\x20without\x20imagemagick\x20if\x20libwebp\x20on\x20ffmpeg\x20doesnt\x20isntalled\x20(pkg\x20install\x20imagemagick)",
    "error",
    "black",
    "argv",
    "object",
    "APIs",
    "219231MqxGxn",
    "Selamat\x20datang\x20@user\x20di\x20group\x20@subject\x20utamakan\x20baca\x20desk\x20ya\x20\x0a@desc",
    "data",
    "2036529vvzxWV",
    "credsUpdate",
    "group-participants.update",
    "1154705hQLQSN",
    "connectionUpdate",
    "createInterface",
    "convert",
    "CONNECTING",
    "tmpdir",
    "\x20--",
    "white",
    "blueBright",
    "lowdb",
    "connection.update",
    "participantsUpdate",
    "makeWASocket",
    "replace",
    "READ",
    "onDelete",
    "lodash",
    "https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json",
    "./sessions/creds.json",
    "./lib/simple",
    "requiring\x20new\x20plugin\x20\x27",
    "-delete",
    "creds.update",
    "spawn",
    "env",
    "@adiwajshing/baileys",
    "yargs/yargs",
    "pino",
    "support",
    "ENTER\x20A\x20VALID\x20NUMBER\x20START\x20WITH\x20REGION\x20CODE.\x20Example\x20:\x2062xxx:\x0a",
    "re\x20-\x20require\x20plugin\x20\x27",
    "ffmpeg",
    "reloadHandler",
    "--\x20WARNING:\x20creds.json\x20is\x20broken,\x20please\x20delete\x20it\x20first\x20--",
    "join",
    "--\x20Please\x20wait,\x20generating\x20code...\x20--",
    "yellow",
    "keys",
    "exit",
    "isInit",
    "plugins",
    "off",
    "length",
    "find",
    "then",
    "‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\x5c-",
    "magick",
    "delete",
    "12945632nCBsAm",
    "connect",
    "\x5c$&",
    "APIKeys",
    "messages.upsert",
    "buttonsMessage",
    "silent",
    "logger",
    "52hYQNfE",
    "isBuffer",
    "PORT",
    "Stickers\x20may\x20not\x20animated\x20without\x20libwebp\x20on\x20ffmpeg\x20(--enable-ibwebp\x20while\x20compiling\x20ffmpeg)",
    "templateMessage",
    "output",
    "--pairing",
  ];
  _0x5b40 = function () {
    return _0x1ccc65;
  };
  return _0x5b40();
}
(function (_0x56617c, _0x4d141e) {
  const _0x54a23f = _0x481f,
    _0x5ac6cc = _0x56617c();
  while (!![]) {
    try {
      const _0x4128ec =
        (parseInt(_0x54a23f(0x1fe)) / 0x1) *
          (parseInt(_0x54a23f(0x1ef)) / 0x2) +
        (parseInt(_0x54a23f(0x220)) / 0x3) *
          (parseInt(_0x54a23f(0x1bd)) / 0x4) +
        -parseInt(_0x54a23f(0x226)) / 0x5 +
        (-parseInt(_0x54a23f(0x1e3)) / 0x6) *
          (parseInt(_0x54a23f(0x1b5)) / 0x7) +
        (-parseInt(_0x54a23f(0x219)) / 0x8) *
          (-parseInt(_0x54a23f(0x223)) / 0x9) +
        (parseInt(_0x54a23f(0x216)) / 0xa) *
          (-parseInt(_0x54a23f(0x1c9)) / 0xb) +
        (-parseInt(_0x54a23f(0x1e9)) / 0xc) *
          (-parseInt(_0x54a23f(0x20f)) / 0xd);
      if (_0x4128ec === _0x4d141e) break;
      else _0x5ac6cc["push"](_0x5ac6cc["shift"]());
    } catch (_0x5446a3) {
      _0x5ac6cc["push"](_0x5ac6cc["shift"]());
    }
  }
})(_0x5b40, 0xefff1),
  (async () => {
    const _0x2cbaaa = _0x481f;
    require(_0x2cbaaa(0x1dd));
    const {
        useMultiFileAuthState: _0x533881,
        DisconnectReason: _0x53ced4,
        generateForwardMessageContent: _0x23bf46,
        prepareWAMessageMedia: _0x901b1,
        generateWAMessageFromContent: _0x5042cb,
        generateMessageID: _0x54905c,
        downloadContentFromMessage: _0x347add,
        makeInMemoryStore: _0x30e0b3,
        jidDecode: _0x4612e5,
        PHONENUMBER_MCC: _0x26ff49,
        fetchLatestBaileysVersion: _0x1785e0,
        proto: _0x2d6734,
      } = require(_0x2cbaaa(0x23f)),
      _0x49398d = require(_0x2cbaaa(0x241)),
      _0x524852 = require("ws"),
      _0x680a27 = require("path"),
      _0x32f29f = require("fs"),
      _0x276499 = require(_0x2cbaaa(0x240)),
      _0xc1204a = require(_0x2cbaaa(0x206)),
      _0x1ecbca = require(_0x2cbaaa(0x236)),
      _0x392d82 = require("syntax-error"),
      _0x2a59f1 = require(_0x2cbaaa(0x241)),
      _0x470804 = require("os"),
      _0x58b12a = require(_0x2cbaaa(0x1ca)),
      _0x88dc80 = require(_0x2cbaaa(0x20b));
    let _0x23c5c6 = require(_0x2cbaaa(0x239));
    var _0x563417;
    try {
      _0x563417 = require(_0x2cbaaa(0x22f));
    } catch (_0x3b3723) {
      _0x563417 = require(_0x2cbaaa(0x211));
    }
    const { Low: _0x133260, JSONFile: _0x2627b5 } = _0x563417,
      _0x27d6e2 = require("./lib/mongoDB"),
      _0x196326 = require(_0x2cbaaa(0x20d)),
      _0x2ab022 =
        process[_0x2cbaaa(0x21d)]["includes"](_0x2cbaaa(0x1ee)) ||
        process["argv"][_0x2cbaaa(0x209)](_0x2cbaaa(0x1c3)),
      _0x4c1105 = process[_0x2cbaaa(0x21d)][_0x2cbaaa(0x209)](_0x2cbaaa(0x1fc)),
      _0x47ba5e = _0x196326[_0x2cbaaa(0x228)]({
        input: process[_0x2cbaaa(0x1d1)],
        output: process[_0x2cbaaa(0x207)],
      }),
      _0x3bc568 = (_0x5317ce) =>
        new Promise((_0x55cf2f) =>
          _0x47ba5e[_0x2cbaaa(0x1f9)](_0x5317ce, _0x55cf2f)
        );
    (global[_0x2cbaaa(0x1cd)] = (
      _0x453b31,
      _0x5ea4d0 = "/",
      _0x1d2fe3 = {},
      _0x1bc09b
    ) =>
      (_0x453b31 in global[_0x2cbaaa(0x21f)]
        ? global[_0x2cbaaa(0x21f)][_0x453b31]
        : _0x453b31) +
      _0x5ea4d0 +
      (_0x1d2fe3 || _0x1bc09b
        ? "?" +
          new URLSearchParams(
            Object[_0x2cbaaa(0x1f7)]({
              ..._0x1d2fe3,
              ...(_0x1bc09b
                ? {
                    [_0x1bc09b]:
                      global[_0x2cbaaa(0x1b8)][
                        _0x453b31 in global["APIs"]
                          ? global["APIs"][_0x453b31]
                          : _0x453b31
                      ],
                  }
                : {}),
            })
          )
        : "")),
      (global["timestamp"] = { start: new Date() });
    const _0x410e4c = process[_0x2cbaaa(0x23e)][_0x2cbaaa(0x1bf)] || 0xbb8;
    (global["opts"] = new Object(
      _0x276499(process[_0x2cbaaa(0x21d)][_0x2cbaaa(0x1fa)](0x2))
        ["exitProcess"](![])
        [_0x2cbaaa(0x208)]()
    )),
      (global[_0x2cbaaa(0x1d4)] = new RegExp(
        "^[" +
          (opts[_0x2cbaaa(0x1d4)] || _0x2cbaaa(0x1b2))["replace"](
            /[|\\{}()[\]^$+*?.\-\^]/g,
            _0x2cbaaa(0x1b7)
          ) +
          "]"
      )),
      (global["db"] = new _0x133260(
        /https?:\/\//[_0x2cbaaa(0x1cb)](opts["db"] || "")
          ? new cloudDBAdapter(opts["db"])
          : /mongodb/[_0x2cbaaa(0x1cb)](opts["db"])
          ? new _0x27d6e2(opts["db"])
          : new _0x2627b5(
              (opts["_"][0x0] ? opts["_"][0x0] + "_" : "") + "database.json"
            )
      )),
      (global["DATABASE"] = global["db"]),
      (global[_0x2cbaaa(0x1cf)] = async function _0x4cc2a4() {
        const _0x379258 = _0x2cbaaa;
        if (global["db"]["READ"])
          return new Promise((_0x189c0c) =>
            setInterval(function () {
              const _0x14b2d3 = _0x481f;
              !global["db"][_0x14b2d3(0x234)]
                ? (clearInterval(this),
                  _0x189c0c(
                    global["db"][_0x14b2d3(0x222)] == null
                      ? global["loadDatabase"]()
                      : global["db"][_0x14b2d3(0x222)]
                  ))
                : null;
            }, 0x1 * 0x3e8)
          );
        if (global["db"][_0x379258(0x222)] !== null) return;
        (global["db"][_0x379258(0x234)] = !![]),
          await global["db"][_0x379258(0x1fd)](),
          (global["db"][_0x379258(0x234)] = ![]),
          (global["db"]["data"] = {
            users: {},
            chats: {},
            stats: {},
            msgs: {},
            sticker: {},
            ...(global["db"][_0x379258(0x222)] || {}),
          }),
          (global["db"][_0x379258(0x1e6)] = _0x1ecbca[_0x379258(0x1e6)](
            global["db"][_0x379258(0x222)]
          ));
      }),
      loadDatabase();
    const _0x515740 = "" + (opts["_"][0x0] || _0x2cbaaa(0x1ce));
    global[_0x2cbaaa(0x1ac)] = !_0x32f29f[_0x2cbaaa(0x1ea)](_0x515740);
    const {
        state: _0x5193b2,
        saveState: _0x1bd7c8,
        saveCreds: _0x31aff6,
      } = await _0x533881(_0x515740),
      { version: _0x5a53bc, isLatest: _0x59dded } = await _0x1785e0();
    console[_0x2cbaaa(0x201)](
      _0x88dc80["magenta"](
        _0x2cbaaa(0x203) +
          _0x5a53bc["join"](".") +
          _0x2cbaaa(0x1f6) +
          _0x59dded +
          _0x2cbaaa(0x22c)
      )
    );
    const _0x12181b = {
      printQRInTerminal: !_0x2ab022,
      syncFullHistory: !![],
      markOnlineOnConnect: !![],
      connectTimeoutMs: 0xea60,
      defaultQueryTimeoutMs: 0x0,
      keepAliveIntervalMs: 0x2710,
      generateHighQualityLinkPreview: !![],
      patchMessageBeforeSending: (_0x5826df) => {
        const _0x108a11 = _0x2cbaaa,
          _0x328020 = !!(
            _0x5826df[_0x108a11(0x1ba)] ||
            _0x5826df[_0x108a11(0x1c1)] ||
            _0x5826df[_0x108a11(0x218)]
          );
        return (
          _0x328020 &&
            (_0x5826df = {
              viewOnceMessage: {
                message: {
                  messageContextInfo: {
                    deviceListMetadataVersion: 0x2,
                    deviceListMetadata: {},
                  },
                  ..._0x5826df,
                },
              },
            }),
          _0x5826df
        );
      },
      auth: _0x5193b2,
      browser: [_0x2cbaaa(0x1f4), "Chrome", "20.0.04"],
      logger: _0x49398d({ level: _0x2cbaaa(0x1bb) }),
      version: (await (await _0x58b12a(_0x2cbaaa(0x237)))["json"]())[
        _0x2cbaaa(0x1f2)
      ],
    };
    global[_0x2cbaaa(0x215)] = _0x23c5c6[_0x2cbaaa(0x232)](_0x12181b);
    if (!opts[_0x2cbaaa(0x1cb)]) {
      if (global["db"])
        setInterval(async () => {
          const _0x7aabbb = _0x2cbaaa;
          if (global["db"][_0x7aabbb(0x222)])
            await global["db"][_0x7aabbb(0x1dc)]();
          if (
            !opts[_0x7aabbb(0x20c)] &&
            (global[_0x7aabbb(0x242)] || {})["find"]
          )
            (tmp = [_0x470804[_0x7aabbb(0x22b)](), _0x7aabbb(0x20c)]),
              tmp[_0x7aabbb(0x1f3)]((_0x400962) =>
                _0xc1204a[_0x7aabbb(0x23d)](_0x7aabbb(0x1b0), [
                  _0x400962,
                  _0x7aabbb(0x1fb),
                  "3",
                  _0x7aabbb(0x1e0),
                  "f",
                  _0x7aabbb(0x23b),
                ])
              );
        }, 0x1e * 0x3e8);
    }
    async function _0x478e67(_0x219e74) {
      const _0x33abb9 = _0x2cbaaa,
        { connection: _0x4b1c77, lastDisconnect: _0x514321 } = _0x219e74;
      global[_0x33abb9(0x217)][_0x33abb9(0x1b6)] = new Date();
      _0x514321 &&
        _0x514321["error"] &&
        _0x514321["error"][_0x33abb9(0x1c2)] &&
        _0x514321["error"][_0x33abb9(0x1c2)][_0x33abb9(0x1d9)] !==
          _0x53ced4[_0x33abb9(0x1f0)] &&
        conn["ws"][_0x33abb9(0x1e5)] !== _0x524852[_0x33abb9(0x22a)] &&
        console[_0x33abb9(0x201)](global[_0x33abb9(0x1a5)](!![]));
      if (global["db"][_0x33abb9(0x222)] == null) await loadDatabase();
    }
    (_0x2ab022 || _0x4c1105) &&
      _0x32f29f[_0x2cbaaa(0x1ea)](_0x2cbaaa(0x238)) &&
      !conn[_0x2cbaaa(0x1d6)][_0x2cbaaa(0x200)]["registered"] &&
      (console[_0x2cbaaa(0x201)](_0x88dc80[_0x2cbaaa(0x1a9)](_0x2cbaaa(0x1a6))),
      process[_0x2cbaaa(0x1ab)](0x0));
    if (_0x2ab022 && !conn[_0x2cbaaa(0x1d6)]["creds"]["registered"]) {
      if (_0x4c1105)
        throw new Error(
          "Cannot\x20use\x20pairing\x20code\x20with\x20mobile\x20api"
        );
      const { registration: _0x2598d5 } = { registration: {} };
      let _0x25d10d = "";
      do {
        _0x25d10d = await _0x3bc568(
          _0x88dc80[_0x2cbaaa(0x22e)](_0x2cbaaa(0x243))
        );
      } while (
        !Object[_0x2cbaaa(0x1aa)](_0x26ff49)[_0x2cbaaa(0x212)]((_0x4141a0) =>
          _0x25d10d["startsWith"](_0x4141a0)
        )
      );
      _0x47ba5e["close"](),
        (_0x25d10d = _0x25d10d[_0x2cbaaa(0x233)](/\D/g, "")),
        console[_0x2cbaaa(0x201)](
          _0x88dc80[_0x2cbaaa(0x1f1)](
            _0x88dc80[_0x2cbaaa(0x1c5)](_0x2cbaaa(0x1a8))
          )
        ),
        setTimeout(async () => {
          const _0x334585 = _0x2cbaaa;
          let _0x1198cf = await conn[_0x334585(0x1d2)](_0x25d10d);
          (_0x1198cf =
            _0x1198cf?.[_0x334585(0x20e)](/.{1,4}/g)?.[_0x334585(0x1a7)]("-") ||
            _0x1198cf),
            console["log"](
              _0x88dc80[_0x334585(0x21c)](
                _0x88dc80[_0x334585(0x214)](_0x334585(0x1d7))
              ),
              _0x88dc80[_0x334585(0x21c)](
                _0x88dc80[_0x334585(0x22d)](_0x1198cf)
              )
            );
        }, 0xbb8);
    }
    process["on"]("uncaughtException", console[_0x2cbaaa(0x21b)]);
    const _0x28dbc1 = (_0x30060a) => {
      const _0x59cfa4 = _0x2cbaaa;
      _0x30060a = require[_0x59cfa4(0x1c6)](_0x30060a);
      let _0x5db7b4,
        _0x2a1668 = 0x0;
      do {
        if (_0x30060a in require[_0x59cfa4(0x213)])
          delete require[_0x59cfa4(0x213)][_0x30060a];
        (_0x5db7b4 = require(_0x30060a)), _0x2a1668++;
      } while (
        (!_0x5db7b4 ||
        Array["isArray"](_0x5db7b4) ||
        _0x5db7b4 instanceof String
          ? !(_0x5db7b4 || [])[_0x59cfa4(0x1af)]
          : typeof _0x5db7b4 == _0x59cfa4(0x21e) &&
            !Buffer[_0x59cfa4(0x1be)](_0x5db7b4)
          ? !Object[_0x59cfa4(0x1aa)](_0x5db7b4 || {})[_0x59cfa4(0x1af)]
          : !![]) &&
        _0x2a1668 <= 0xa
      );
      return _0x5db7b4;
    };
    let _0x4dd1f2 = !![];
    global[_0x2cbaaa(0x1a5)] = function (_0x530614) {
      const _0x507ca1 = _0x2cbaaa;
      let _0x4f81f4 = _0x28dbc1("./handler");
      if (_0x530614) {
        try {
          global["conn"]["ws"]["close"]();
        } catch {}
        global[_0x507ca1(0x215)] = {
          ...global[_0x507ca1(0x215)],
          ..._0x23c5c6[_0x507ca1(0x232)](_0x12181b),
        };
      }
      return (
        !_0x4dd1f2 &&
          (conn["ev"][_0x507ca1(0x1ae)](
            _0x507ca1(0x1b9),
            conn[_0x507ca1(0x1d8)]
          ),
          conn["ev"][_0x507ca1(0x1ae)](
            _0x507ca1(0x225),
            conn[_0x507ca1(0x231)]
          ),
          conn["ev"][_0x507ca1(0x1ae)](
            "message.delete",
            conn[_0x507ca1(0x235)]
          ),
          conn["ev"][_0x507ca1(0x1ae)](
            _0x507ca1(0x230),
            conn[_0x507ca1(0x227)]
          ),
          conn["ev"]["off"](_0x507ca1(0x23c), conn[_0x507ca1(0x224)])),
        (conn[_0x507ca1(0x1e8)] = _0x507ca1(0x221)),
        (conn[_0x507ca1(0x1f8)] = "Selamat\x20tinggal\x20@user\x20👋"),
        (conn["promote"] = _0x507ca1(0x1e1)),
        (conn[_0x507ca1(0x1d3)] = "@user\x20sekarang\x20bukan\x20admin!"),
        (conn[_0x507ca1(0x1d8)] = _0x4f81f4[_0x507ca1(0x1d8)]["bind"](conn)),
        (conn["participantsUpdate"] =
          _0x4f81f4[_0x507ca1(0x231)][_0x507ca1(0x202)](conn)),
        (conn[_0x507ca1(0x235)] =
          _0x4f81f4[_0x507ca1(0x1b4)][_0x507ca1(0x202)](conn)),
        (conn["connectionUpdate"] = _0x478e67["bind"](conn)),
        (conn["credsUpdate"] = _0x31aff6[_0x507ca1(0x202)](conn)),
        conn["ev"]["on"](_0x507ca1(0x1b9), conn[_0x507ca1(0x1d8)]),
        conn["ev"]["on"]("group-participants.update", conn[_0x507ca1(0x231)]),
        conn["ev"]["on"]("message.delete", conn[_0x507ca1(0x235)]),
        conn["ev"]["on"](_0x507ca1(0x230), conn[_0x507ca1(0x227)]),
        conn["ev"]["on"](_0x507ca1(0x23c), conn[_0x507ca1(0x224)]),
        (_0x4dd1f2 = ![]),
        !![]
      );
    };
    let _0xfbc211 = _0x680a27[_0x2cbaaa(0x1a7)](__dirname, _0x2cbaaa(0x1ad)),
      _0x38c1fe = (_0x1ca55d) => /\.js$/[_0x2cbaaa(0x1cb)](_0x1ca55d);
    global[_0x2cbaaa(0x1ad)] = {};
    for (let _0x2dbb31 of _0x32f29f[_0x2cbaaa(0x1f5)](_0xfbc211)[
      _0x2cbaaa(0x1ed)
    ](_0x38c1fe)) {
      try {
        global[_0x2cbaaa(0x1ad)][_0x2dbb31] = require(_0x680a27[
          _0x2cbaaa(0x1a7)
        ](_0xfbc211, _0x2dbb31));
      } catch (_0x198e42) {
        conn["logger"][_0x2cbaaa(0x21b)](_0x198e42),
          delete global[_0x2cbaaa(0x1ad)][_0x2dbb31];
      }
    }
    console[_0x2cbaaa(0x201)](
      Object[_0x2cbaaa(0x1aa)](global[_0x2cbaaa(0x1ad)])
    ),
      (global[_0x2cbaaa(0x1ec)] = (_0x3113db, _0x35b4ad) => {
        const _0x44998a = _0x2cbaaa;
        if (_0x38c1fe(_0x35b4ad)) {
          let _0x40f89c = _0x680a27[_0x44998a(0x1a7)](_0xfbc211, _0x35b4ad);
          if (_0x40f89c in require[_0x44998a(0x213)]) {
            delete require["cache"][_0x40f89c];
            if (_0x32f29f[_0x44998a(0x1ea)](_0x40f89c))
              conn["logger"][_0x44998a(0x1d0)](
                _0x44998a(0x244) + _0x35b4ad + "\x27"
              );
            else
              return (
                conn[_0x44998a(0x1bc)][_0x44998a(0x1d5)](
                  _0x44998a(0x1e7) + _0x35b4ad + "\x27"
                ),
                delete global["plugins"][_0x35b4ad]
              );
          } else
            conn[_0x44998a(0x1bc)]["info"](
              _0x44998a(0x23a) + _0x35b4ad + "\x27"
            );
          let _0x411a74 = _0x392d82(
            _0x32f29f[_0x44998a(0x210)](_0x40f89c),
            _0x35b4ad
          );
          if (_0x411a74)
            conn["logger"][_0x44998a(0x21b)](
              _0x44998a(0x1df) + _0x35b4ad + "\x27\x0a" + _0x411a74
            );
          else
            try {
              global["plugins"][_0x35b4ad] = require(_0x40f89c);
            } catch (_0x9093fd) {
              conn[_0x44998a(0x1bc)][_0x44998a(0x21b)](_0x9093fd);
            } finally {
              global["plugins"] = Object[_0x44998a(0x1db)](
                Object[_0x44998a(0x1f7)](global[_0x44998a(0x1ad)])["sort"](
                  ([_0x510347], [_0x59a90c]) =>
                    _0x510347[_0x44998a(0x1e2)](_0x59a90c)
                )
              );
            }
        }
      }),
      Object[_0x2cbaaa(0x1c7)](global[_0x2cbaaa(0x1ec)]),
      _0x32f29f[_0x2cbaaa(0x204)](
        _0x680a27[_0x2cbaaa(0x1a7)](__dirname, "plugins"),
        global["reload"]
      ),
      global["reloadHandler"]();
    async function _0x5adff5() {
      const _0x16186c = _0x2cbaaa;
      let _0x547272 = await Promise[_0x16186c(0x1e4)](
          [
            _0xc1204a[_0x16186c(0x23d)](_0x16186c(0x245)),
            _0xc1204a[_0x16186c(0x23d)](_0x16186c(0x1eb)),
            _0xc1204a["spawn"](_0x16186c(0x245), [
              _0x16186c(0x1ff),
              _0x16186c(0x1de),
              _0x16186c(0x21b),
              _0x16186c(0x1c4),
              _0x16186c(0x1da),
              "-frames:v",
              "1",
              "-f",
              "webp",
              "-",
            ]),
            _0xc1204a[_0x16186c(0x23d)](_0x16186c(0x229)),
            _0xc1204a[_0x16186c(0x23d)]("magick"),
            _0xc1204a[_0x16186c(0x23d)]("gm"),
            _0xc1204a[_0x16186c(0x23d)](_0x16186c(0x1b0), [_0x16186c(0x20a)]),
          ]["map"]((_0x568faa) => {
            return Promise["race"]([
              new Promise((_0xefe56c) => {
                const _0xe8e291 = _0x481f;
                _0x568faa["on"](_0xe8e291(0x1cc), (_0x2e4897) => {
                  _0xefe56c(_0x2e4897 !== 0x7f);
                });
              }),
              new Promise((_0x465155) => {
                const _0x503eb2 = _0x481f;
                _0x568faa["on"](_0x503eb2(0x21b), (_0x2285de) =>
                  _0x465155(![])
                );
              }),
            ]);
          })
        ),
        [
          _0x56d1f2,
          _0xf82eba,
          _0x493eb5,
          _0x5d3325,
          _0x297d5e,
          _0x1d4e33,
          _0x776094,
        ] = _0x547272;
      console["log"](_0x547272);
      let _0x2db56a = (global[_0x16186c(0x242)] = {
        ffmpeg: _0x56d1f2,
        ffprobe: _0xf82eba,
        ffmpegWebp: _0x493eb5,
        convert: _0x5d3325,
        magick: _0x297d5e,
        gm: _0x1d4e33,
        find: _0x776094,
      });
      Object[_0x16186c(0x1c7)](global[_0x16186c(0x242)]);
      if (!_0x2db56a[_0x16186c(0x245)])
        conn[_0x16186c(0x1bc)][_0x16186c(0x1d5)](
          "Please\x20install\x20ffmpeg\x20for\x20sending\x20videos\x20(pkg\x20install\x20ffmpeg)"
        );
      if (_0x2db56a[_0x16186c(0x245)] && !_0x2db56a["ffmpegWebp"])
        conn["logger"][_0x16186c(0x1d5)](_0x16186c(0x1c0));
      if (
        !_0x2db56a[_0x16186c(0x229)] &&
        !_0x2db56a[_0x16186c(0x1b3)] &&
        !_0x2db56a["gm"]
      )
        conn[_0x16186c(0x1bc)][_0x16186c(0x1d5)](_0x16186c(0x21a));
    }
    _0x5adff5()
      [_0x2cbaaa(0x1b1)](() =>
        conn["logger"][_0x2cbaaa(0x1d0)]("Quick\x20Test\x20Done")
      )
      [_0x2cbaaa(0x1c8)](_0x2cbaaa(0x205));
  })();
