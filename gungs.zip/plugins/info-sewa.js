let fetch = require("node-fetch");

let handler = async (m, { conn, command }) => {
  let buffer = await fetch(
    `https://telegra.ph/file/1c53a85e78e81e2aaad9c.jpg`
  ).then((res) => res.buffer());
  conn.sendFile(
    m.chat,
    buffer,
    `
    ▧「 *P E M B A Y A R A N* 」

    *🎗️E-Walet*
    • Dana = 0852-9031-3883
    • Shopee = 0852-9031-3883
    
    *🎗️Rekening*
    • BRI = 752801017821539
    
    👤A/N : AGUNG UTAMA
    
    *Jika telah melakukan pembayaran silahkan kirimkan bukti pembayaran ke WhatsApp Owner.*`,
    m
  );
};

handler.help = handler.command = [
  "donasi",
  "donate",
  "sewa",
  "sewabot",
  "belibot",
];
handler.tags = ["main"];
module.exports = handler;
