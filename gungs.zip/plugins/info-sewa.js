let fetch = require("node-fetch");

let handler = async (m, { conn, command }) => {
  let buffer = await fetch(
    `https://telegra.ph/file/3a34bfa58714bdef500d9.jpg`
  ).then((res) => res.buffer());
  conn.sendFile(
    m.chat,
    buffer,
    "hasil.jpg",
    `▧「 *P E M B A Y A R A N* 」

    *🎗️E-Walet*
    • Dana = 0852-9031-3883
    • Shopee = 0852-9031-3883
    
    *🎗️Rekening*
    • BRI = 752801017821539
    
    👤A/N : AGUNG UTAMA
    
    *Jika telah melakukan pembayaran silahkan kirimkan bukti pembayaran ke WhatsApp Owner.*`,
    m
  );
};

handler.help = handler.command = [
  "donasi",
  "donate",
  "sewa",
  "sewabot",
  "belibot",
];
handler.tags = ["main"];
module.exports = handler;
