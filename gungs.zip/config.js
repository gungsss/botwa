global.owner = ["6285290313883"];
global.mods = ["6285290313883"];
global.prems = ["6285290313883"];
global.nameowner = "gung's";
global.numberowner = "6285290313883";
global.mail = "agungs79u@gmail.com";
global.gc = "https://chat.whatsapp.com/F5Ksj5T16ns2Epix6p4Bup";
global.instagram = "https://instagram.com/_agung79";
global.wm = "© gung's";
global.wait = "_*Tunggu sedang di proses...*_";
global.eror = "_*Server Error*_";
global.stiker_wait = "*⫹⫺ Stiker sedang dibuat...*";
global.packname = "Made With Rexx Bot";
global.author = "by: gung's";
global.maxwarn = "2"; // Peringatan maksimum

//INI WAJIB DI ISI!//
global.btc = "we98t7gungs";
//Daftar terlebih dahulu https://api.botcahx.eu.org

//INI OPTIONAL BOLEH DI ISI BOLEH JUGA ENGGA//
global.lann = "we98t7gungs";
//Daftar https://api.betabotz.eu.org

global.APIs = {
  btc: "https://api.botcahx.eu.org",
};
global.APIKeys = {
  "https://api.botcahx.eu.org": "APIKEY",
};

let fs = require("fs");
let chalk = require("chalk");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  delete require.cache[file];
  require(file);
});
