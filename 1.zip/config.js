import { watchFile, unwatchFile } from "fs";
import chalk from "chalk";
import { fileURLToPath } from "url";
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

// Owner
global.owner = [["6285290313883", "gungs", true]];
global.mods = [];
global.prems = [];
// Info
global.nomorwa = "6285290313883";
global.packname = "© Sticker by";
global.author = "gungs";
global.namebot = "gungs";
global.wm = "© gungs";
global.stickpack = "© Sticker by";
global.stickauth = "gungs";
global.fotonya = "https://telegra.ph/file/45c3c45486c7a9114c371.jpg";
// Link Sosmed
global.sig = "https://instagram.com/_agung79";
global.sgh = "https://github.com/gungsss";
global.sgc = "https://chat.whatsapp.com/JI0ur14tpj65omrjZalppI";
// Donasi
global.psaweria = "";
global.ptrakterr = "";
global.povo = "085290313883";
// Info Wait
global.wait = "⏳ Loading...";
global.eror = "❗Terjadi Kesalahan Coba Lagi Nanti!";
global.multiplier = 69;
// Apikey
global.lol = "Elaina";
global.rose = "Rs-RyHarJR";
global.xyro = "ClaraKeyOfficial";
global.zein = "zenzkey_8bb60993ae";
global.xteam = "cristian9407";
global.xzn = "RyHar";

// Web Apikey
global.APIs = {
  xyro: "https://api.xyroinee.xyz",
  popcat: "https://api.popcat.xyz",
};

/*Apikey*/
global.APIKeys = {
  "https://api.xyroinee.xyz": "ClaraKeyOfficial",
  "https://api.zahwazein.xyz": "zenzkey_8bb60993ae",
  "https://api.xteam.xyz": "cristian9407",
  "https://api.lolhuman.xyz": "Elaina",
  "https://api.itsrose.life": "Rs-RyHarJR",
  "https://xzn.wtf": "RyHar",
};

/*============== EMOJI ==============*/
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      level: "📊",
      limit: "🎫",
      health: "❤️",
      exp: "✨",
      atm: "💳",
      money: "💰",
      bank: "🏦",
      potion: "🥤",
      diamond: "💎",
      common: "📦",
      uncommon: "🛍️",
      mythic: "🎁",
      legendary: "🗃️",
      superior: "💼",
      pet: "🔖",
      trash: "🗑",
      armor: "🥼",
      sword: "⚔️",
      pickaxe: "⛏️",
      fishingrod: "🎣",
      wood: "🪵",
      rock: "🪨",
      string: "🕸️",
      horse: "🐴",
      cat: "🐱",
      dog: "🐶",
      fox: "🦊",
      robo: "🤖",
      petfood: "🍖",
      iron: "⛓️",
      gold: "🪙",
      emerald: "❇️",
      upgrader: "🧰",
      bibitanggur: "🌱",
      bibitjeruk: "🌿",
      bibitapel: "☘️",
      bibitmangga: "🍀",
      bibitpisang: "🌴",
      anggur: "🍇",
      jeruk: "🍊",
      apel: "🍎",
      mangga: "🥭",
      pisang: "🍌",
      botol: "🍾",
      kardus: "📦",
      kaleng: "🏮",
      plastik: "📜",
      gelas: "🧋",
      chip: "♋",
      umpan: "🪱",
      skata: "🧩",
    };
    let results = Object.keys(emot)
      .map((v) => [v, new RegExp(v, "gi")])
      .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};
let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  import(`${file}?update=${Date.now()}`);
});
