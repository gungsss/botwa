import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, args, command, text }) => {
if (!text) throw `❓Linknya Mana?`
m.reply(wait)
try {
const axios = require('axios');
const fs = require('fs');

async function downloadTikTokVideo(url, outputPath) {
  try {
    const response = await axios.get(url, {
      responseType: 'stream',
    });

    const writer = fs.createWriteStream(outputPath);
    response.data.pipe(writer);

    return new Promise((resolve, reject) => {
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
  } catch (error) {
    throw new Error('Gagal mengunduh video TikTok');
  }
}

// Contoh penggunaan
const videoUrl = 'https://www.tiktok.com/@username/video/1234567890';
const outputFilePath = './video.mp4';

downloadTikTokVideo(videoUrl, outputFilePath)
  .then(() => {
    console.log('Video berhasil diunduh');
  })
  .catch((error) => {
    console.error(error);
  });
  }
  }
handler.help = ['tiktok 🅕']
handler.tags = ['downloader']
handler.command = /^(tiktok|tt|ttdl|tiktokdl)$/i
handler.limit = true

export default handler