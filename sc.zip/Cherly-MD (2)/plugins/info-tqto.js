import fs from 'fs'

let handler = async (m, { conn }) => {
	let tqto = `Thanks Too :
	
- Allah SWT 
- BochilGamng
- Xct007
- Ekuzika
- Nurutomo
- ImYanXiao
- Xyroinee
- VynaaChan
- XTRAM-TEAM

All Developer WhatsApp Bot.
`;
	await conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/5478e28cc3ace94df0d43.jpg' }, caption: tqto }, m)
}
handler.help = ['tqto 🅕']
handler.tags = ['main']
handler.command = /^(tqto)$/i;

export default handler;
