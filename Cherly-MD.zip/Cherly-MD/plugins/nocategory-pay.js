let handler = async (m, { conn }) => {
  await conn.relayMessage(
    m.chat,
    {
      requestPaymentMessage: {
        noteMessage: {
          extendedTextMessage: {
            text: "• Ovo = 0852-9031-3883\n• Dana = 0852-9031-3883\n• Gopay = 0852-9031-3883\n• Mandiri = 1560020056281\n• BTPN Jenius = 90390174040\n📍𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁!! \n⚠️𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶!!",
            currencyCodeIso4217: "USD",
            requestFrom: "0@s.whatsapp.net",
            expiryTimestamp: 8600,
            amount: 10000,
          },
        },
      },
    },
    {}
  );
};
handler.help = ["pay"];
handler.tags = ["nocategory"];
handler.command = /^pay$/i;
export default handler;
