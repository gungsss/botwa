let handler = async (m, { conn }) => {
  let sewa = `
👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑
Atau menjadi Member VIP Bot.

Keuntungan Premium:

1️⃣. Unlimited Limit
2️⃣. Bisa akses Fitur
 • HD/Remini Foto
 • NSFW (18+)
 • Dan Fitur Lainnya

- Lebih murah dari Aplikasi
- Tidak perlu install Aplikasi
- Tidak Boros Penyimpanan
- Tidak ada Iklan
- Proses Cepat

📍Cara penggunaan HD/Remini
Kirim/Reply Foto dengan caption:
*.hdr*
*.remini*
*.color*

益 𝗟𝗜𝗦𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 益

•📮1 Minggu = Rp.5.000
•📮2 Minggu = Rp.10.000
•📮1 Bulan = Rp.15.000
•📮Permanen = Rp.35.000

[ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 ]
• ShoopePay = 0852-9031-3883
• Dana = 0852-9031-3883
📍𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁!! 
⚠️𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶!!

📣[ 𝗧𝗲𝘀𝘁𝗶𝗺𝗼𝗻𝗶 ]
https://www.instagram.com/_agung79/?igshid=NTc4MTIwNjQ2YQ==
`;
  conn.reply(m.chat, sewa, m);
};
handler.help = ["premium"];
handler.tags = ["main"];
handler.command = /^(prem|premium)$/i;

export default handler;
