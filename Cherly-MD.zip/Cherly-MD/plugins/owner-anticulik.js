import fs from "fs";
let handler = (m) => m;

handler.all = async function (m, { isBlocked }) {
  if (isBlocked) return;
  // ketika ada yang invite/kirim link grup di chat pribadi
  if (
    (m.mtype === "groupInviteMessage" ||
      m.text.startsWith("Undangan untuk bergabung") ||
      m.text.startsWith("Invitation to join") ||
      m.text.startsWith("Buka tautan ini")) &&
    !m.isBaileys &&
    !m.isGroup
  ) {
    let teks = `益 𝗟𝗜𝗦𝗧 𝗦𝗘𝗪𝗔 𝗕𝗢𝗧 益

•📮1 Minggu = Rp.5.000
•📮2 Minggu = Rp.10.000
•📮1 Bulan = Rp.25.000
•📮3 Bulan = Rp.40.000

📌Untuk pembelian Sewa Bot 1&3 Bulan Gratis Premium untuk 3 Admin Grup selama 7 Hari.

*📣[ Testimoni ]*
https://www.instagram.com/_agung79/?igshid=NTc4MTIwNjQ2YQ==
`;
    this.reply(m.chat, teks, m);
    const data = global.owner.filter(([id, isCreator]) => id && isCreator);
    this.sendContact(
      m.chat,
      data.map(([id, name]) => [id, name]),
      m
    );
  }
};

export default handler;
