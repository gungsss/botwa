import axios from "axios"
import { readFileSync } from "fs"


let handler = async (m, { conn, usedPrefix, command, text }) => {

let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) throw '❗Send Foto Nya Kak' 
if (!text) throw 'Masukan Angka Tingkatannya Maksimal 10\nContoh: .beauty 3' 
m.reply(wait)
let media = await q.download()
const imageBufer = media

const sharp = require('sharp');

// Fungsi untuk memproses gambar dengan filter kecantikan
async function applyBeautyFilter(inputPath, outputPath) {
  try {
    // Baca gambar masukan
    const image = sharp(inputPath);

    // Terapkan filter kecantikan
    const processedImage = await image
      .sharpen(0.5)
      .median(3)
      .gamma(0.8)
      .toFile(outputPath);

    console.log('Filter kecantikan berhasil diterapkan!');
    console.log('Gambar hasil tersimpan di:', outputPath);
  } catch (error) {
    console.error('Terjadi kesalahan:', error);
  }
}
}

// Contoh penggunaan
const inputPath = 'path/to/input/image.jpg';
const outputPath = 'path/to/output/image.jpg';

applyBeautyFilter(inputPath, outputPath);

handler.help = ['beauty']
handler.tags = ['ai']
handler.command = /^(beauty)$/i
handler.limit = true
handler.group = true

export default handler