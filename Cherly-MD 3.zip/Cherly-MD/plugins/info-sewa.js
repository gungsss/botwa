let handler = async (m, { conn }) => {
  let sewa = `
👾𝚂𝚎𝚠𝚊 𝙱𝚘𝚝👾
Atau undang Bot ke grup kalian.

Keuntungan Sewa Bot:

1️⃣. Jaga Grup Kalian
• Anti Virus
• Anti Toxic
• Anti Spam
• Anti Link Grup lain
2️⃣. Bermain game sepuasnya di Grup Sendiri.
3️⃣. Bisa main tebak-tebakan dan teka teki.

Kalian juga Bisa akses fitur Maker&Tools seperti:
  - Bikin sticker
  - Edit Nama
  - Tools 
Dan Fitur AI (Artificial Intelligence)
Dengan menggunakan code *.Gungs*
Contoh:
*.Gungs apa yang di maksud Cinta?*

益 𝗟𝗜𝗦𝗧 𝗦𝗘𝗪𝗔 𝗕𝗢𝗧 益

•📮1 Minggu = Rp.5.000
•📮2 Minggu = Rp.10.000
•📮1 Bulan = Rp.25.000
•📮3 Bulan = Rp.40.000

[ 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡 ]
• ShoopePay = 0852-9031-3883
• Dana = 0852-9031-3883
📍𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁!! 
⚠️𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶!!

📌Untuk pembelian Sewa Bot 1&3 Bulan Gratis Premium untuk 3 Admin Grup selama 7 Hari.

📣[ 𝗧𝗲𝘀𝘁𝗶𝗺𝗼𝗻𝗶 ]
https://www.instagram.com/_agung79/?igshid=NTc4MTIwNjQ2YQ==
`;
  conn.reply(m.chat, sewa, m);
};
handler.help = ["sewa"];
handler.tags = ["main"];
handler.command = /^(sewa)$/i;

export default handler;
