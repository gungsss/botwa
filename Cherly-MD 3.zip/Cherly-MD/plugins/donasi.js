let handler = async (m, { conn }) => {
  let fotonya = "https://telegra.ph/file/ce992cdbcd0ea831f0041.jpg";
  let sewa = `Hai Kak, Ingin Donasi?, Silahkan Donasi Ke Payment Yang Ada Di Bawah, Dengan Kamu Berdonasi Berarti Kamu Berkontribusi Dalam Perkembangan Bot Ini..


❏──「 *Payment* 」
│ • *ShopeePay:* 0852-9031-3883
│ • *Dana:* 0852-9031-3883
│ • *Bri:* 7528-01-017821-53-9
❏──────────────๑

Rekening di atas beratas namakan
*AGUNG UTAMA*
Selain itu SALAH!!

Terima Kasih Yang Sudah Donasi, Berapapun Donasi Kamu Akan Sangat Saya Hargain >,<
`;
  conn.sendFile(m.chat, fotonya, "anu.jpg", sewa, m);
};
handler.help = ["sewa"];
handler.tags = ["main"];
handler.command = /^(donasi|donate)$/i;

export default handler;
