import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'

lconst axios = require('axios');

async function searchAnime(query) {
  try {
    const response = await axios.get(`https://api.xyroinee.xyz/api/others/toanime?url=${url}&apikey=${global.xyro}`);
    return response.data;
  } catch (error) {
    console.error('Error searching anime:', error);
    return null;
  }
}

async function getAnimeDetails(id) {
  try {
    const response = await axios.get(`https://api.xyroinee.xyz/api/others/toanime?url=${url}&apikey=${global.xyro}`);
    return response.data;
  } catch (error) {
    console.error('Error getting anime details:', error);
    return null;
  }
}

module.exports = {
  searchAnime,
  getAnimeDetails
}
handler.help = ['toanime']
handler.tags = ['ai']
handler.command = /^(jadianime|toanime)$/i
handler.premium = false
handler.limit = true
handler.group = true

export default handler