import axios from "axios"
import fetch from 'node-fetch'
import uploadImage from '../lib/uploadImage.js'
import FormData from "form-data";
import Jimp from "jimp";

const fs = require('fs');
const ffmpeg = require('fluent-ffmpeg');

let handler = async (m, { conn, usedPrefix, command, args }) => {
let response = args.join(' ').split('|')
if (!args[0]) throw '❗Kirim/Reply Video.'
m.reply(wait)
const inputFilePath = 'path/to/input/video.mp4';
const outputFilePath = 'path/to/output/video_hd.mp4';

ffmpeg(inputFilePath)
  .outputOptions('-s', '1920x1080') // Mengatur resolusi menjadi 1920x1080
  .outputOptions('-c:v', 'libx264') // Menggunakan codec libx264
  .outputOptions('-crf', '23') // Mengatur tingkat kualitas video (CRF 23)
  .output(outputFilePath)
  .on('end', () => {
    console.log('Video HD berhasil dibuat!');
  })
  .on('error', (err) => {
    console.error('Terjadi kesalahan saat membuat video HD:', err);
  })
}
  .run();
handler.help = ['hdv']
handler.tags = ['ai']
handler.command = /^(hdv)$/i
handler.limit = true
handler.group = false
handler.premium = true

export default handler