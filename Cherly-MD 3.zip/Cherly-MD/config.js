import { watchFile, unwatchFile } from "fs";
import chalk from "chalk";
import { fileURLToPath } from "url";
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

// Owner
global.owner = [["6285290313883", "Gung's", true]];
global.mods = [];
global.prems = [];
// Info
global.nomorwa = "6285290313883";
global.packname = "© Sticker by";
global.author = "Gungs-MD";
global.namebot = "Gungs - MD";
global.wm = "© Gungs Official 🅥";
global.stickpack = "© Sticker by";
global.stickauth = "Gungs-MD";
// Link Sosmed
global.sig = "https://www.instagram.com/_agung79/?igshid=NTc4MTIwNjQ2YQ==";
global.sgh = "https://github.com/Xyroinee";
global.sgc = "https://chat.whatsapp.com/DlmuSo3QT4TEKmK6ipgL0p";
// Donasi
global.psaweria = "";
global.ptrakterr = "";
global.povo = "0852-9031-3883";
// Info Wait
global.wait = "⏳ Loading...";
global.eror = "Terjadi Kesalahan Coba Lagi Nanti!";
global.multiplier = 69;
// Apikey
global.xyro = "UnlimitedXyroineeKey";
// Catatan : Jika Mau Work Fiturnya
// Masukan Apikeymu
// Gapunya Apikey? Ya Daftar
// Website: https://api.xyroinee.xyz
// Daftar Ke Website Tersebut Untuk
// Mendapatkan Apikey Kamu
global.APIs = {
  xyro: "https://api.xyroinee.xyz",
};

/*Apikey*/
global.APIKeys = {
  "https://api.xyroinee.xyz": "UnlimitedXyroineeKey",
};

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  import(`${file}?update=${Date.now()}`);
});
