let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  const caption = `
▧「 *PEMBAYARAN* 」

*🎗️E-Walet*
• Dana = 0852-9031-3883
• Shopee = 0852-9031-3883

*🎗️Rekening*
• BRI = 752801017821539

👤A/N : AGUNG UTAMA

📍𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁!!
⚠️𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶!!

`.trim();
  conn.sendMessage(
    m.chat,
    {
      image: { url: "https://telegra.ph/file/77857de148df3b35c1bc0.jpg" },
      caption: caption,
    },
    { quoted: m }
  );
};
handler.help = ["payment"];
handler.tags = ["main"];
handler.command = /^(pay|payment|qris)$/i;
handler.group = false;

handler.register = false;
export default handler;
