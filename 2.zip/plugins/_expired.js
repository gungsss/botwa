export async function all(m) {
    let chat = global.db.data.chats[m.chat]
    if (m.isGroup && chat.expired != 0) {
        if (new Date() - chat.expired > 0) {
            this.reply(m.chat, `Waktunya *${this.user.name}* Untuk Meninggalkan Group\nJangan lupa sewa lagi ya!`, null).then(() => {
                this.sendContact(m.chat, global.config.owner, m).then(() => {
                    this.groupLeave(m.chat)
                    chat.expired = 0
                })
            })
        }
    }
    return !0
}