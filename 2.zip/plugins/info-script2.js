import fs from "fs";

let handler = async (m, { conn }) => {
  let loadd = [
    "《██▒▒▒▒▒▒▒▒▒▒▒》10%",
    "《████▒▒▒▒▒▒▒▒▒》30%",
    "《███████▒▒▒▒▒▒》50%",
    "《██████████▒▒▒》70%",
    "《█████████████》100%",
    "𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...",
  ];

  let { key } = await conn.sendMessage(m.chat, { text: "_Loading_" }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let pfft = `*🖨️Source Code gungs*

*gungs V.1.4.6*
 • *Type:* Apikey Xyroinee
 • *Bailey:* @whiskeysockets
 • *Total Fitur:* 450+
 • *Harga:* 25k

*gungs V.1.4.7*
 • *Type:* Scraper (7 Apikey(lol,rose))
 • *Bailey:* @whiskeysockets
 • *Total Fitur:* 750+
 • *Ada Fitur RPG*
 • *Harga:* 40k


*💥Kelebihan:*
- Free Apikey
- Loading pake Animasi

*📍Note:*
- SC tidak ada Node Module

Minat?
Ketik *.pay*
`;
  conn.sendMessage(m.chat, {
    text: pfft,
    contextInfo: {
      externalAdReply: {
        title: `gungs Official 🅥`,
        body: global.author,
        thumbnailUrl: `https://telegra.ph/file/bbe72cae463e9527ae0bc.jpg`,
        sourceUrl: `https://chat.whatsapp.com/GNeX7gNWTQn4B0JdnHyxls`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
};
handler.command = /^(mysc)$/i;

export default handler;
