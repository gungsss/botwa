import { youtube } from "@xct007/frieren-scraper"
let handler = async (m, { conn, text, usedPrefix, command }) => {
    let result = await youtube.search(text)
    let caption = result.map((v, i) => {
        return `
_*${i + 1}. ${v.title}*_
⏱️ Duration : ${v.duration}
📤 Upload : ${v.uploaded}
👁 Views : ${v.views}
🔗 Link : ${v.url}
`.trim()
    }).filter(v => v).join('\n\n')
    m.reply(caption)
}
handler.help = ['ytsearch']
handler.tags = ['search']
handler.command = /^(yt(s|search)|youtubesearch)$/i
handler.limit = true
export default handler