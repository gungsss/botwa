import PhoneNumber from "awesome-phonenumber";
import { promises } from "fs";
import { join } from "path";
import fetch from "node-fetch";
import { xpRange } from "../lib/levelling.js";
import moment from "moment-timezone";
import os from "os";
import fs from "fs";
let tags = {
  main: "Main",
  game: "Game",
  rpg: "RPG Games",
  xp: "Exp & Limit",
  sticker: "Sticker",
  kerang: "Kerang Ajaib",
  quotes: "Quotes",
  fun: "Fun",
  anime: "Anime & Manga",
  group: "Group & Admin",
  store: "Store",
  premium: "Premium",
  nsfw: "Nsfw",
  anonymous: "Anonymous Chat",
  internet: "Internet",
  genshin: "Genshin",
  news: "News",
  downloader: "Downloader",
  search: "Searching",
  tools: "Tools",
  primbon: "Primbon",
  nulis: "MagerNulis & Logo",
  audio: "Audio Editing",
  maker: "Maker",
  database: "Database",
  quran: "Al Quran",
  owner: "Owner",
  info: "Info",
  random: "Random",
  sound: "Sound",
  nc: "No Category",
};
const defaultMenu = {
  before: `
_*❏ WhatsApp Bot Multi Device*_
●────━───༺༻───━───●
┏─────────────────⬣
┆         《 BOT INFO 》
┗┬──────────────┈ ⳹
┏┆⚘ *Nama Bot:* gungs
┆┆⚘ *Jam:* %wib WIB
┆┆⚘ *Hari:* %week %weton
┆┆⚘ *Tanggal:* %date
┆┆⚘ *Mode:* Publik
┆┆⚘ *Pengguna Bot:* %totalreg orang
┗┬──────────────┈ ⳹
┏┤      《 USER INFO 》
┆┗──────────────┈ ⳹
┆⚘ *Nama:* %name
┆⚘ *Tag:* %tag
┆⚘ *Status:* %status
┆⚘ *Limit:* %limit
┆⚘ *Level:* %level
┆⚘ *Xp:* %exp / %maxexp
┆⚘ *Rank:* %role
┗─────────────────⬣
●────━───༺༻───━───●

%readmore`.trimStart(),
  header: "❏┄┅━┅┄〈 〘 _*%category*_ 〙\n│",
  body: "┊⌬ %cmd",
  footer: "│\n┗━═┅═━━┅┄๑\n",
  after: "",
};
let handler = async (
  m,
  { conn, usedPrefix, __dirname, isOwner, isMods, isPrems }
) => {
  let loadd = [
    "《██▒▒▒▒▒▒▒▒▒▒▒》10%",
    "《████▒▒▒▒▒▒▒▒▒》30%",
    "《███████▒▒▒▒▒▒》50%",
    "《██████████▒▒▒》70%",
    "《█████████████》100%",
    "𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...",
  ];

  let { key } = await conn.sendMessage(m.chat, { text: "_Loading_" }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let wib = moment.tz("Asia/Jakarta").format("HH:mm:ss");
  let _package =
    JSON.parse(
      await promises
        .readFile(join(__dirname, "../package.json"))
        .catch((_) => ({}))
    ) || {};
  let { exp, level, role } = global.db.data.users[m.sender];
  let { min, xp, max } = xpRange(level, global.multiplier);
  let tag = `@${m.sender.split("@")[0]}`;
  let user = global.db.data.users[m.sender];
  let limit = isPrems ? "Unlimited" : user.limit;
  let name = user.registered ? user.name : conn.getName(m.sender);
  let status = isMods
    ? "🎗️Developer🎗️"
    : isOwner
    ? "🎗️Owner🎗️"
    : isPrems
    ? "👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑"
    : user.level > 1000
    ? "Elite User"
    : "Free User";
  let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
      ? conn.user.jid
      : m.sender;
  let d = new Date(new Date() + 3600000);
  let locale = "id";
  let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][
    Math.floor(d / 84600000) % 5
  ];
  let week = d.toLocaleDateString(locale, { weekday: "long" });
  let date = d.toLocaleDateString(locale, {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  let dateIslamic = Intl.DateTimeFormat(locale + "-TN-u-ca-islamic", {
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(d);
  let time = d.toLocaleTimeString(locale, {
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  });
  let _uptime = process.uptime() * 1000;
  let _muptime;
  if (process.send) {
    process.send("uptime");
    _muptime =
      (await new Promise((resolve) => {
        process.once("message", resolve);
        setTimeout(resolve, 1000);
      })) * 1000;
  }
  let muptime = clockString(_muptime);
  let uptime = clockString(_uptime);
  let totalreg = Object.keys(global.db.data.users).length;
  let rtotalreg = Object.values(global.db.data.users).filter(
    (user) => user.registered == true
  ).length;
  let help = Object.values(global.plugins)
    .filter((plugin) => !plugin.disabled)
    .map((plugin) => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: "customPrefix" in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      };
    });
  for (let plugin of help)
    if (plugin && "tags" in plugin)
      for (let tag of plugin.tags) if (!(tag in tags) && tag) tags[tag] = tag;
  conn.menu = conn.menu ? conn.menu : {};
  let before = conn.menu.before || defaultMenu.before;
  let header = conn.menu.header || defaultMenu.header;
  let body = conn.menu.body || defaultMenu.body;
  let footer = conn.menu.footer || defaultMenu.footer;
  let after =
    conn.menu.after ||
    (conn.user.jid == global.conn.user.jid
      ? ""
      : `Powered by https://wa.me/${global.conn.user.jid.split`@`[0]}`) +
      defaultMenu.after;
  let _text = [
    before,
    ...Object.keys(tags).map((tag) => {
      return (
        header.replace(/%category/g, tags[tag]) +
        "\n" +
        [
          ...help
            .filter((menu) => menu.tags && menu.tags.includes(tag) && menu.help)
            .map((menu) => {
              return menu.help
                .map((help) => {
                  return body
                    .replace(/%cmd/g, menu.prefix ? help : "%p" + help)
                    .replace(/%islimit/g, menu.limit ? "🅛" : "")
                    .replace(/%isPremium/g, menu.premium ? "🅟" : "")
                    .trim();
                })
                .join("\n");
            }),
          footer,
        ].join("\n")
      );
    }),
    after,
  ].join("\n");
  let text =
    typeof conn.menu == "string"
      ? conn.menu
      : typeof conn.menu == "object"
      ? _text
      : "";
  let replace = {
    "%": "%",
    p: usedPrefix,
    uptime,
    muptime,
    me: conn.getName(conn.user.jid),
    npmname: _package.name,
    npmdesc: _package.description,
    version: _package.version,
    exp: exp - min,
    maxexp: xp,
    totalexp: exp,
    xp4levelup: max - exp,
    github: _package.homepage
      ? _package.homepage.url || _package.homepage
      : "[unknown github url]",
    level,
    limit,
    name,
    weton,
    week,
    date,
    dateIslamic,
    time,
    totalreg,
    rtotalreg,
    role,
    tag,
    status,
    wib,
    readmore: readMore,
  };
  text = text.replace(
    new RegExp(
      `%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`,
      "g"
    ),
    (_, name) => "" + replace[name]
  );

  let ihu = "https://telegra.ph/file/45c3c45486c7a9114c371.jpg";

  conn.sendMessage(m.chat, {
    text: text,
    contextInfo: {
      externalAdReply: {
        title: `gungs - Official`,
        body: global.author,
        thumbnailUrl: ihu,
        sourceUrl: `https://chat.whatsapp.com/GNeX7gNWTQn4B0JdnHyxls`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
};
handler.help = ["menu"];
handler.tags = ["main"];
handler.command = /^(allmenu)$/i;
handler.register = false;
export default handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

function wish() {
  let wishloc = "";
  const time = moment.tz("Asia/Jakarta").format("HH");
  wishloc = "Hi";
  if (time >= 0) {
    wishloc = "🌃Selamat Malam";
  }
  if (time >= 4) {
    wishloc = "🌃Selamat Pagi";
  }
  if (time >= 11) {
    wishloc = "🌞Selamat Siang";
  }
  if (time >= 15) {
    wishloc = "️🌇Selamat Sore";
  }
  if (time >= 18) {
    wishloc = "🌃Selamat Malam";
  }
  if (time >= 23) {
    wishloc = "🌃Selamat Malam";
  }
  return wishloc;
}

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}
