import { sticker } from '../lib/sticker.js'

let handler = async (m, { conn, command, usedPrefix, text }) => {
    if (!text) return m.reply(`Masukan Text!\n\nContoh :\n${usedPrefix + command} Saya Pki`)
    let loadd = [
 '《██▒▒▒▒▒▒▒▒▒▒▒》10%',
 '《████▒▒▒▒▒▒▒▒▒》30%',
 '《███████▒▒▒▒▒▒》50%',
 '《██████████▒▒▒》70%',
 '《█████████████》100%',
 '𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
    let teks = text ? text: m.quoted && m.quoted.text ? m.quoted.text: m.text
    let res = global.API('lol', '/api/attp', { text: teks }, 'apikey')
    let stiker = await sticker(false, res, global.config.stickpack, global.config.stickauth)
    await conn.sendFile(m.chat, stiker, false, false, m)
}
handler.help = ['attp <teks>']
handler.tags = ['sticker']
handler.command = /^(attp)$/i
handler.limit = true
export default handler