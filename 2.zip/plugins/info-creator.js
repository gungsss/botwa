import fetch from "node-fetch";
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
      ? conn.user.jid
      : m.sender;
  let name = await conn.getName(who);

  const sentMsg = await conn.sendContactArray(
    m.chat,
    [
      [
        `${nomorwa}`,
        `Tn gungs 🅥`,
        `Developer Bot `,
        `Ponsel`,
        `agungs79u@gmail.com`,
        `Kendal - Indonesia`,
        `https://instagram.com/_agung79`,
        `Developer gungs`,
      ],
    ],
    m
  );
};

handler.help = ["owner", "creator"];
handler.tags = ["main"];
handler.command = /^(owner|creator)/i;
export default handler;
