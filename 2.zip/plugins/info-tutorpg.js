import fs from "fs";

let handler = async (m, { conn }) => {
  let loadd = [
    "《██▒▒▒▒▒▒▒▒▒▒▒》10%",
    "《████▒▒▒▒▒▒▒▒▒》30%",
    "《███████▒▒▒▒▒▒》50%",
    "《██████████▒▒▒》70%",
    "《█████████████》100%",
    "𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...",
  ];

  let { key } = await conn.sendMessage(m.chat, { text: "_Loading_" }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let pfft = `┌─〔 TUTORIAL  〕
│ 
├〘 Tutorial EPIC RPG 〙
├➥ *.claim*
│   Staterpack yang bisa di klaim 
│   12 jam sekali
├➥ *.mulung*
├➥ *.adventure*
├➥ *.petualang*
│   Untuk mencari resource seperti 
│   Money, Exp, dll..,dibutuhkan  
│   minimal 80 nyawa untuk bisa 
│   melakukannya dan, kamu tidak 
│   dapat spam karena ada delay 5 
│   menit
├➥ *.use potion <jumlah>*
│   Untuk memakai potion/untuk 
│   mengisi nyawa/health
├➥ *.shop buy potion <jumlah>*
│   Untuk membeli potion dan ketik 
├➥ *.use potion <jumlah>*
│   untuk menggunakan potion
├➥ *.shop <args>*
│   Untuk membeli atau menjual sesuatu
├➥ *.shop buy <crate> <jumlah>*
│   Untuk membeli Crate
├➥ *.profile*
├➥ *.pp*
├➥ *.profil*
│   untuk mengetahui No whatsapmu, dll
├➥ *.inv*
├➥ *.inventory*
├➥ *.bal*
│   Untuk mengecek nyawa, money, dll.
├➥ *.judi <jumlah>*
│   *_Jangan judi, Karena gk bakal_*
│   *_balik modal.BENERAN GK BOHONG_*
│  
├➥ *©BOT 2020-2024*
└─「 *Tutorial Main BOT* 」

⌕ ❙❘❙❙❘❙❚❙❘❙❙❚❙❘❙❘❙❚❙❘❙❙❚❙❘❙❙❘❙❚❙❘ ⌕
`;
  conn.sendMessage(m.chat, {
    text: pfft,
    contextInfo: {
      externalAdReply: {
        title: `gungs Official 🅥`,
        body: global.author,
        thumbnailUrl: `https://telegra.ph/file/bbe72cae463e9527ae0bc.jpg`,
        sourceUrl: `https://chat.whatsapp.com/JI0ur14tpj65omrjZalppI`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
};
handler.help = ["tutorrpg"];
handler.tags = ["main"];
handler.command = /^(tutorialrpg|tutorrpg)$/i;

export default handler;
