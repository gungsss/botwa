import fs from "fs";

let handler = async (m, { conn }) => {
  let loadd = [
    "《██▒▒▒▒▒▒▒▒▒▒▒》10%",
    "《████▒▒▒▒▒▒▒▒▒》30%",
    "《███████▒▒▒▒▒▒》50%",
    "《██████████▒▒▒》70%",
    "《█████████████》100%",
    "𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...",
  ];

  let { key } = await conn.sendMessage(m.chat, { text: "_Loading_" }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let pfft = `*📮Panel Bot/Minecraft📮*

🖨️LIST HARGA PANEL🖨️


💮RAM 5GB/CPU 80% : 8K/BULAN

💮RAM 6GB /CPU 90% : 12K/BULAN
 
💮RAM 7GB/CPU150% : 15k/BULAN

💮RAM 8GB/CPU 200% : 20K/BULAN
 
💮RAM UNLI/CPU UNLI% 25k/BULAN
   
 • Keuntungan Panel
-Run on 24jam ✓
-Tidak boros Kuota ✓
-Tidak boros penyimpanan ✓
-Tidak perlu Ekstrak ✓
-Tidak ribet ✓
-Bisa ditinggal saat offline ✓

📝 NOTE
PASTIKAN SUDAH PAHAM MEMAKAI PANEL JIKA BELOM SILAHKAN TONTON VIDEO TUTORIAL DI YOITUB, KAMI AKAN MEMBERIKAN GARANSI 1BULAN, JIKA PANEL MENGALAMI KENDALA


Minat?
Ketik *.pay*
`;
  conn.sendMessage(m.chat, {
    text: pfft,
    contextInfo: {
      externalAdReply: {
        title: `gungs Official 🅥`,
        body: global.author,
        thumbnailUrl: `https://telegra.ph/file/bbe72cae463e9527ae0bc.jpg`,
        sourceUrl: `https://chat.whatsapp.com/JI0ur14tpj65omrjZalppI`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
};
handler.command = /^(panel)$/i;

export default handler;
