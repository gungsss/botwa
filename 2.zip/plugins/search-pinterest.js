import fetch from 'node-fetch'

let handler = async (m, { conn, command, usedPrefix, text }) => {
  if (!text) return m.reply(`Masukan Query! \n\nContoh : \n${usedPrefix + command} Hu Tao`)
  try {
    let response = await fetch(global.API('xzn', '/api/pinterest', { search: text }, 'apikey'))
    let json = await response.json()
    let { media } = json.getRandom()
    await conn.sendFile(m.chat, 'https://external-content.duckduckgo.com/iu/?u=' + media.url, false, 'Ini Dia Kak', m)
  } catch {
      throw 'Failed :('
  }
}
handler.help = ['pinterest']
handler.tags = ['search']
handler.command = /^(pin(terest)?)$/i
handler.limit = true
export default handler