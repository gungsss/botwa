import { simi } from "../lib/scrape.js"
let handler = async (m, { conn, text }) => {
    if (!text) throw 'Mau ngomong apa kak sama simi?'
    try {
        let teks = await simi(text, 'id')
        m.reply(teks)
    } catch (e) {
        throw 'Maaf kak aku ga paham hehehe...'
    }
}
handler.help = ['simi']
handler.tags = ['fun']
handler.command = /^(simi)$/i
handler.onlyprem = true
handler.limit = true
export default handler