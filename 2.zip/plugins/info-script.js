import fs from "fs";

let handler = async (m, { conn }) => {
  let loadd = [
    "《██▒▒▒▒▒▒▒▒▒▒▒》10%",
    "《████▒▒▒▒▒▒▒▒▒》30%",
    "《███████▒▒▒▒▒▒》50%",
    "《██████████▒▒▒》70%",
    "《█████████████》100%",
    "𝙻𝙾𝙰𝙳𝙸𝙽𝙶 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴𝙳...",
  ];

  let { key } = await conn.sendMessage(m.chat, { text: "_Loading_" }); //Pengalih isu

  for (let i = 0; i < loadd.length; i++) {
    await conn.sendMessage(m.chat, { text: loadd[i], edit: key });
  }
  let pfft = `*gungs V.1.4.8*
	
*Source Code Type:*
 • *Base* : Plugins (Scraper)
 • *Total Feature* : 750+
 • *Language* : NodeJs
 • *Bailey* : @adiwashing
 • *Bailey Supp* : @whiskeysockets

Jika anda menginginkan Script ini silahkan hubungi nomor dibawah ini:

Owner Contact:
wa.me/6285290313883
`;
  conn.sendMessage(m.chat, {
    text: pfft,
    contextInfo: {
      externalAdReply: {
        title: `gungs Official 🅥`,
        body: global.author,
        thumbnailUrl: `https://telegra.ph/file/bbe72cae463e9527ae0bc.jpg`,
        sourceUrl: `https://chat.whatsapp.com/JI0ur14tpj65omrjZalppI`,
        mediaType: 1,
        renderLargerThumbnail: true,
      },
    },
  });
};
handler.command = /^(sc|script)$/i;

export default handler;
