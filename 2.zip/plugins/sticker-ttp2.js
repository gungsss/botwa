import { ttp } from "../lib/scrape.js";
import { sticker } from "../lib/sticker.js";

let handler = async (m, { conn, command, usedPrefix, text }) => {
  if (!text)
    return m.reply(
      `Masukan Text! \n\nContoh : \n${usedPrefix + command} gungs Cantik`
    );
  let { result } = await ttp(text);
  let { data } = await conn.getFile(result);
  let stiker = await sticker(
    data,
    false,
    global.config.stickpack,
    global.config.stickauth
  );
  conn.sendFile(m.chat, stiker, false, false, m);
};
handler.help = ["ttp2"];
handler.tags = ["sticker"];
handler.command = /^(ttp2)$/i;
handler.limit = true;
export default handler;
