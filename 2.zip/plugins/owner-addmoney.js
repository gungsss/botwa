let handler = async (m, { conn, text }) => {
    if (!text) throw 'Masukkan Jumlah Money Yang Akan Diberi'
    let who
    if (m.isGroup) who = m.mentionedJid[0]
    else who = m.chat
    if (!who) throw 'Tag Orangnya'
    let txt = text.replace('@' + who.split`@`[0], '').trim()
    if (isNaN(txt)) throw 'Hanya Angka'
    let poin = parseInt(txt)
    let money = poin
    if (money < 1) throw 'Minimal 1'
    let user = global.db.data.users
    user[who].koin += poin
    if (money > 999999999999999) return m.reply('Ngotak Dikit Lah Kalau Ngasih, Kebanyakan Itu!\nLu Mau Systemku Error??') 

    conn.reply(m.chat, `Selamat @${who.split`@`[0]}. Kamu Mendapatkan +${money} Money!`, m, {
        contextInfo: {
            mentionedJid: [who]
        }
    }) 
}

handler.help = ['addmoney']
handler.tags = ['owner']
handler.command = /^(addmoney)$/
handler.rowner = false
handler.premium = false
handler.owner = true

export default handler

