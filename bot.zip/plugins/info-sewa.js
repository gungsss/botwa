let handler = async (m, { conn }) => {
  let sewa = `
👾𝚂𝚎𝚠𝚊 𝙱𝚘𝚝👾
Atau undang Bot ke grup kalian.

益 𝗟𝗜𝗦𝗧 𝗦𝗘𝗪𝗔 𝗕𝗢𝗧 益

•📮1 Minggu = Rp.5.000
•📮2 Minggu = Rp.10.000
•📮1 Bulan = Rp.25.000
•📮3 Bulan = Rp.40.000

*[ Keuntungan Sewa Bot ]*
1️⃣. Khusus untuk:
• Pembelian 1 Bulan = free premium 7 hari
• Pembelian 3 Bulan = free Premium 14 hari
Untuk 3 Admin Grup
2️⃣. Jaga Grup dari:
• Anti Virus
• Anti Toxic
• Anti Spam
• Anti Link Grup lain
3️⃣. Bermain game sepuasnya di Grup Sendiri.
4️⃣. Bisa main tebak-tebakan dan teka teki.

Kalian juga Bisa akses fitur Maker&Tools seperti:
  - Bikin sticker
  - Edit Nama
  - Tools
  - Dan 350 Fitur Lainnya 
  
Ada juga Fitur AI (Artificial Intelligence) untuk searching tentang apapun.
Dengan menggunakan code *.Gungs*
Contoh:
*.Gungs apa yang di maksud Cinta?*

--------------------------------------
MINAT?
Silahkan ketik *.pay*

`;
  conn.reply(m.chat, sewa, m);
};
handler.help = ["sewa 🅕"];
handler.tags = ["main"];
handler.command = /^(sewa)$/i;

export default handler;
