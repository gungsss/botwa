let handler = async (m, { conn }) => {
let sewa = `
👑ℙ𝕣𝕖𝕞𝕚𝕦𝕞👑
Atau menjadi Member VIP Bot.

益 𝗟𝗜𝗦𝗧 𝗣𝗥𝗘𝗠𝗜𝗨𝗠 益

•📮1 Minggu = Rp.5.000
•📮2 Minggu = Rp.10.000
•📮1 Bulan = Rp.15.000
•📮Permanen = Rp.35.000

*[ Keuntungan Premium ]*
1️⃣. Unlimited Limit
2️⃣. Bisa akses Fitur
 • HD/Remini Foto
 • NSFW
 • Dan 350 Fitur Lainnya

- Lebih murah dari Aplikasi
- Tidak perlu install Aplikasi
- Tidak Boros Penyimpanan
- Tidak ada Iklan
- Proses Cepat (3-5 detik)

📍Cara penggunaan HD/Remini
Kirim/Reply Foto dengan caption:
*.hdr*
*.remini*
*.color*

---------------------------------------
MINAT?
Silahkan ketik *.pay*

`
conn.reply(m.chat, sewa, m)
}
handler.help = ['premium 🅕']
handler.tags = ['main']
handler.command = /^(prem|premium)$/i

export default handler