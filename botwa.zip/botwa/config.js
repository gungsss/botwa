import { watchFile, unwatchFile } from "fs";
import chalk from "chalk";
import { fileURLToPath } from "url";
const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

// Owner
global.owner = [["6289662933232", "gungs 🅥", true]];
global.mods = ["6289662933232"];
global.prems = ["6289662933232"];
// Info
global.nomorwa = "6289662933232";
global.packname = "© Sticker by";
global.author = "gungs";
global.namebot = "gungs";
global.wm = "© Cherly Official 🅥";
global.stickpack = "© Sticker by";
global.stickauth = "gungs";
// Link Sosmed
global.sig = "https://instagram.com/gungse_saputra15?igshid=NTc4MTIwNjQ2YQ==";
global.sgh = "https://github.com/Xyroinee";
global.sgc = "https://chat.whatsapp.com/DlmuSo3QT4TEKmK6ipgL0p";
// Donasi
global.psaweria = "https://s.id/gungs";
global.ptrakterr = "https://s.id/gungs";
global.povo = "0896-6293-3232";
// Info Wait
global.wait = "⏳ Loading...";
global.eror = "Terjadi Kesalahan Coba Lagi Nanti!";
global.multiplier = 69;
// Apikey
global.xyro = "UnlimitedXyroineeKey";
// Catatan : Jika Mau Work Fiturnya
// Masukan Apikeymu
// Gapunya Apikey? Ya Daftar
// Website: https://api.xyroinee.xyz
// Daftar Ke Website Tersebut Untuk
// Mendapatkan Apikey Kamu
global.APIs = {
  xyro: "https://api.xyroinee.xyz",
};

/*Apikey*/
global.APIKeys = {
  "https://api.xyroinee.xyz": "UnlimitedXyroineeKey",
};

let file = fileURLToPath(import.meta.url);
watchFile(file, () => {
  unwatchFile(file);
  console.log(chalk.redBright("Update 'config.js'"));
  import(`${file}?update=${Date.now()}`);
});
