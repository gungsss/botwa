import fetch from "node-fetch";
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
  let who =
    m.mentionedJid && m.mentionedJid[0]
      ? m.mentionedJid[0]
      : m.fromMe
      ? conn.user.jid
      : m.sender;
  let name = await conn.getName(who);

  const sentMsg = await conn.sendContactArray(
    m.chat,
    [
      [
        `${nomorwa}`,
        `gungs 🅥`,
        `Developer Bot `,
        `Ponsel`,
        `gungszyx@gmail.com`,
        `Cikarang - Indonesia`,
        `https://s.id/gungs`,
        `Developer gungs`,
      ],
    ],
    m
  );
  let vn = "./vn/owner.mp3";
  await conn.sendFile(m.chat, vn, "kuru.mp3", null, m, true, {
    type: "audioMessage",
    ptt: true,
  });
};

handler.help = ["owner 🅕", "creator 🅕"];
handler.tags = ["main"];
handler.command = /^(owner|creator)/i;
export default handler;
