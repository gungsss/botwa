let handler = async (m, { conn }) => {
  let fotonya = "https://telegra.ph/file/ce992cdbcd0ea831f0041.jpg";
  let sewa = `Hai Kak, Ingin Donasi?, Silahkan Donasi Ke Payment Yang Ada Di Bawah, Dengan Kamu Berdonasi Berarti Kamu Berkontribusi Dalam Perkembangan Bot Ini..

▧「 *PEMBAYARAN* 」

🎗️E-Walet
• Dana = 0852-9031-3883
• Shopee = 0852-9031-3883

🎗️Rekening
• BRI = 7528-01-017821-53-9

Qris? Coming Soon😁

Rekening di atas beratas namakan
*AGUNG UTAMA*
Selain itu SALAH!!

Terima Kasih Yang Sudah Donasi, Berapapun Donasi Kamu Akan Sangat Kami Hargain >,<
`;
  conn.sendFile(m.chat, fotonya, "anu.jpg", sewa, m);
};
handler.help = ["donasi 🅢"];
handler.tags = ["main"];
handler.command = /^(donasi|donate)$/i;

export default handler;
