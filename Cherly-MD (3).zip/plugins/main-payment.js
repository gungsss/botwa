let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender]
  const caption = `
▧「 *PEMBAYARAN* 」

🎗️E-Walet
• Ovo = 0896-6293-3232
• Dana = 0896-6293-3232
• Gopay = 0896-6293-3232
• LinkAja = 0896-6293-3232
• Shopee = 0896-6293-3232

🎗️Rekening
• Mandiri = 1560020056281
• BTPN Jenius = 90390174040

📍𝗦𝗲𝗿𝘁𝗮𝗸𝗮𝗻 𝗦𝗰𝗿𝗲𝗲𝗻𝘀𝗵𝗼𝘁!!
⚠️𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗱𝗶 𝗖𝗵𝗮𝘁 𝗣𝗿𝗶𝗯𝗮𝗱𝗶!!

Qris? Coming Soon😁
`.trim()
  conn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/89291bc27c3aadb7e271c.jpg' }, caption: caption }, {quoted: m })
}
handler.help = ['payment 🅕']
handler.tags = ['main']
handler.command = /^(pay|payment)$/i
handler.group = false

handler.register = false
export default handler