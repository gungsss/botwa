let handler = async (m, { conn }) => {
let fotonya = 'https://telegra.ph/file/ce992cdbcd0ea831f0041.jpg'
let sewa = `Hai Kak, Ingin Donasi?, Silahkan Donasi Ke Payment Yang Ada Di Bawah, Dengan Kamu Berdonasi Berarti Kamu Berkontribusi Dalam Perkembangan Bot Ini..

▧「 *PEMBAYARAN* 」

🎗️E-Walet
• Ovo = 0896-6293-3232
• Dana = 0896-6293-3232
• Gopay = 0896-6293-3232
• LinkAja = 0896-6293-3232
• Shopee = 0896-6293-3232

🎗️Rekening
• Mandiri = 1560020056281
• BTPN Jenius = 90390174040

Qris? Coming Soon😁

Rekening di atas beratas namakan
*AJI SAPUTRA*
Selain itu SALAH!!

Terima Kasih Yang Sudah Donasi, Berapapun Donasi Kamu Akan Sangat Kami Hargain >,<
`
conn.sendFile(m.chat, fotonya, 'anu.jpg', sewa, m)
}
handler.help = ['donasi 🅢']
handler.tags = ['main']
handler.command = /^(donasi|donate)$/i

export default handler
